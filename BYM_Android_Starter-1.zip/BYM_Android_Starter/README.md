# BYM Android Starter

BYM (Be Your Moment) is an Android-first social networking app starter using Kotlin and Jetpack Compose.

## Current status
This is a local UI starter, not yet a production social network. It includes:
- Dark + Purple theme
- Home feed with sample posts
- Local in-memory text post creation
- Like button state
- Bottom navigation: Home, Explore, Create, Likes, Profile

Not yet connected:
- Google sign-in
- Phone OTP
- Firebase database or media storage
- Real users, follows, comments, messaging, moderation

## Build APK using GitHub from an Android phone
1. Download and unzip this project.
2. Create/sign in to GitHub at https://github.com.
3. Create a new repository named `BYM`.
4. Upload the extracted project files and folders to the repository root. Make sure `.github/workflows/android-build.yml` is included.
5. Open the repository's **Actions** tab.
6. Select **Build BYM Android APK**, then **Run workflow** (or push a commit to `main`).
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run, find **Artifacts**, and download `BYM-debug-apk`.
9. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. You may need to allow installation from your browser or file manager.

## Local build requirements
- JDK 17
- Android SDK Platform 35
- Gradle 8.9
- Android Gradle Plugin 8.7.3

## Firebase setup (next development stage)
1. Create a Firebase project at https://console.firebase.google.com.
2. Add an Android app with package name `com.bym.social`.
3. Download `google-services.json` and place it in the `app/` directory.
4. Enable Authentication providers: Google and Phone.
5. Create a Cloud Firestore database.
6. Configure security rules before allowing public access.
7. Add Firebase Android dependencies and the Google Services Gradle plugin in the next implementation step.

Never commit service-account private keys, passwords, OTPs, or other secrets to GitHub. `google-services.json` is a client configuration file, but should still be handled carefully and protected with proper Firebase security rules and App Check.

## Important
The GitHub Actions workflow builds a debug APK for testing. A production release requires signing, release configuration, testing, privacy disclosures, moderation tools and Play Console setup.
